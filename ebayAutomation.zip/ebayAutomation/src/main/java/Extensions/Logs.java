package Extensions;

import Utilities.CommonOps;

public class Logs extends CommonOps {
    public static void addLog(String log){
        System.out.println(log);
    }
}
